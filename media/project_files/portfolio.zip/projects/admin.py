from django.contrib import admin
from .models import Projects, Comment


@admin.register(Projects)
class ProjectsAdmin(admin.ModelAdmin):
    list_display = ('title', 'language', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('title',)


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('user', 'text', 'project', 'created_at', 'active')
    list_filter = ('active', 'created_at')
    search_fields = ('user__username', 'text')

    # Admin panelda bitta knopka bilan izohni o'chirish/yoqish funksiyasi
    actions = ['approve_comments']

    def approve_comments(self, request, queryset):
        queryset.update(active=True)