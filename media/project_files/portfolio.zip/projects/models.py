import uuid

from django.db import models
from django.utils.text import slugify

from data.about import MyInfo
from django.contrib.auth.models import User


class Projects(models.Model):
    LANGUAGE_CHOICES = [(ln.lower(), ln) for ln in MyInfo.PROGRAMMING_LANGUAGES['backend']]

    STATUS_CHOICES = [
        ('completed', 'Tugatilgan'),
        ('in_progress', 'Jarayonda'),
    ]

    title = models.CharField(max_length=100)
    # Slug (URL uchun: masalan-loyiha-nomi)
    slug = models.SlugField(unique=True, null=True, blank=True)

    language = models.CharField(max_length=100, choices=LANGUAGE_CHOICES, default='python')
    description = models.TextField(null=True, blank=True)

    # Media
    image = models.ImageField(upload_to='project_images/', null=True, blank=True)
    document = models.FileField(upload_to='project_files/', null=True, blank=True)

    # Linklar
    github_url = models.URLField(max_length=200, null=True, blank=True)
    live_url = models.URLField(max_length=200, null=True, blank=True)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='completed')

    created_at = models.DateTimeField(auto_now_add=True)
    last_updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-last_updated_at']
        verbose_name = "Loyiha"
        verbose_name_plural = "Loyihalar"

    def save(self, *args, **kwargs):
        if not self.slug:
            # Sarlavhadan slug yasaymiz
            base_slug = slugify(self.title)
            # Agar bunday slug bo'lsa, oxiriga tasodifiy harf qo'shamiz
            if Projects.objects.filter(slug=base_slug).exists():
                self.slug = f"{base_slug}-{uuid.uuid4().hex[:4]}"
            else:
                self.slug = base_slug
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title


# Projects modelini shu faylning o'zidan olamiz

class Comment(models.Model):
    # 1. Qaysi loyihaga tegishli ekanligi (ForeignKey)
    # related_name='comments' juda muhim! Bu orqali biz project.comments.all() deb chaqira olamiz.
    project = models.ForeignKey(Projects, on_delete=models.CASCADE, related_name='comments')

    # 2. Kim yozganligi
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    # 3. Izoh matni
    text = models.TextField()

    # 4. Vaqti
    created_at = models.DateTimeField(auto_now_add=True)

    # 5. Aktivligi (Moderatsiya uchun, masalan, so'kinish bo'lsa False qilib qo'yish mumkin)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ['created_at']  # Eng eski izohlar tepada turadi

    def __str__(self):
        return f"Comment {self.text} by {self.user.username}"
